# FDB Takip 1.2 - Windows (.NET)

Bu sürüm UiPath olmadan çalışan ana sürümdür.

## Yeni özellikler

- Her taramada `Belgeler\FDB Takip Ciktilari\Tum_Kayitlar.xlsx` güncellenir.
- Yeni + değişen kayıtlar tek `Yeni_Guncellenenler_...xlsx` dosyasına çıkar.
- Güncellenen kayıtların **hangi alanlarının değiştiği** hem program ekranında hem Excel'de görünür.
- **Yerel Analiz** sekmesinde Türkçe sorular sorulabilir. Veriler dışarı gönderilmez.
- Analiz sonucunu oluşturan dosyalar `Analiz_Sonucu_...xlsx` olarak dışarı alınabilir.

### Örnek sorular

- `Mehmet Ali Yeniay 1 Temmuz 2026'dan bugüne kaç dosyaya bakmış, kaç dosyayı karara çıkarmış?`
- `Mehmet Ali Yeniay geldiği tarihten itibaren kaç dosyaya bakmış?`
- `2026 yılında en çok karar veren hakim kim?`
- `Ağustos 2026 en fazla hangi dava türü gelmiş?`
- `Menfi Tespit davalarından kaç tane var?`

## Hesap tanımları

- **Baktığı / ele aldığı dosya:** `ELEALINMATARIHI` varsa o tarih, yoksa `DAVATARIHI` kullanılır.
- **Karara çıkardığı dosya:** `KARARTARIHI` ilgili döneme düşen ve karar bilgisi olan kayıt.
- `geldiği tarihten itibaren` ifadesi resmi atama tarihini bilmez; FDB'de hakim adına görünen **en erken dosya tarihini** başlangıç kabul eder ve ekranda bunu açıkça belirtir.

## Derleme / çalıştırma

```powershell
dotnet build
dotnet run
```

Yerel EXE oluşturmak için:

```powershell
dotnet publish -c Release -r win-x64 --self-contained false
```

Kaynak FDB'ye yazılmaz. Okuma geçici Firebird yedeği/kopyası üzerinden yapılır.
