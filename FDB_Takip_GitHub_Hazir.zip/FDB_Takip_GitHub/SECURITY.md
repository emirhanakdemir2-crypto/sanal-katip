# Veri Güvenliği

Bu repo yalnızca uygulama kaynak kodunu içermelidir.

Aşağıdakileri GitHub'a yüklemeyin:

- `.FDB` / `.FBK` veritabanları
- Excel/CSV/TSV çıktıları
- `baseline.tsv`, `state.json` veya uygulamanın yerel veri klasörü
- Taraf, hakim veya dosya içeriği barındıran örnek veriler

Uygulama verileri yerel bilgisayarda tutulur. Kaynak FDB üzerinde yazma yapılmaması tasarımın temel kuralıdır.
