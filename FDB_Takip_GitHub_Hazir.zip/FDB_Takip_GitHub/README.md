# FDB Takip

Firebird `.FDB` içindeki `DOSYALAR` kayıtlarını **salt-okuma mantığıyla** okuyup önceki taramayla karşılaştıran Windows yardımcı uygulamasıdır.

## Ne yapar?

- İlk seçilen FDB'yi **yerel başlangıç hafızası** olarak kaydeder.
- Sonraki FDB'lerde yalnızca **yeni veya bilgisi değişen** dosyaları bulur.
- Yeni + güncellenen kayıtları **tek Excel dosyasına** çıkarır.
- Kaynak FDB'ye yazmaz; okuma için Firebird yedeği ve geçici geri yükleme kullanır.
- `DOSYALAR` tablosunun gerçek birincil anahtarı olan `ESASYILI + ESASNO` ile dosyaları eşleştirir.

## Çekilen alanlar

E.Yılı, E.No, Başkan, Tek Hakim, Dava Tarihi, Hdf/Hedef Süre, Hedef Tarih, Dava Türü, UYAP Dava Türü, Dosya Durumu, Ele Alınma Tarihi, Davacı, Davalı, Duruşma Tarihi, Keşif Tarihi/Saati/Yeri, Bilirkişi Tarihi, Karar Yılı/No/Tarihi, Verilen Karar, UYAP Açıklaması ve Son İşlem Tarihi.

## Veri güvenliği

Bu GitHub deposunda **FDB, Excel, taraf isimleri veya başlangıç kayıt verisi bulunmaz**. Başlangıç hafızası yalnızca programın çalıştığı bilgisayarda `%LOCALAPPDATA%\FDBTakip` altında oluşturulur.

`.gitignore` mahkeme/veri dosyalarının yanlışlıkla repoya eklenmesini engellemek için hazırlanmıştır.

## Gereksinim

- Windows PowerShell / Windows Forms
- Firebird okuma araçları (`isql.exe` ve `gbak.exe`)

Program Firebird araçlarını sistemde arar. Bulamazsa resmi Firebird paketini indirmeyi teklif eder. Kurumsal bilgisayarda script çalıştırma veya yazılım indirme kuralları varsa kurum BT politikasına uyulmalıdır; güvenlik politikaları devre dışı bırakılmamalıdır.

## Çalıştırma

`FDB_Takip.ps1` kaynak dosyasıdır. Kurumsal bilgisayarda PowerShell script çalıştırmaya izin veriliyorsa kurumunuzun onaylı yöntemiyle çalıştırın. Script çalıştırma engellenmişse BT biriminden onay/dağıtım isteyin.

İlk çalıştırmada güncel/baz FDB seçilir ve **TARA VE KARŞILAŞTIR** düğmesine basılır. İlk tarama yalnızca başlangıç hafızasını oluşturur. Sonraki taramalar değişiklik Excel'ini üretir.
