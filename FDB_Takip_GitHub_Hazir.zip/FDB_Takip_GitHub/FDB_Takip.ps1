﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$ErrorActionPreference = 'Stop'
$AppVersion = '1.1.0'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$QueryPath = Join-Path $Root 'query.sql'
$DataDir = Join-Path $env:LOCALAPPDATA 'FDBTakip'
$HistoryDir = Join-Path $DataDir 'history'
$BaselinePath = Join-Path $DataDir 'baseline.tsv'
$StatePath = Join-Path $DataDir 'state.json'
$ConfigPath = Join-Path $DataDir 'config.json'
$RuntimeDir = Join-Path $DataDir 'runtime'
$OutDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'FDB Takip Ciktilari'
New-Item -ItemType Directory -Force -Path $DataDir,$HistoryDir,$RuntimeDir,$OutDir | Out-Null

$FirebirdUrl = 'https://github.com/FirebirdSQL/firebird/releases/download/v4.0.7/Firebird-4.0.7.3271-0-x64.zip'

$Fields = @(
  'ESASYILI','ESASNO','BASKAN','TEKHAKIM','DAVATARIHI','HEDEFSURE','HEDEFTARIH',
  'DAVATURU','UYAPDAVATURU','DOSYADURUMU','ELEALINMATARIHI','DAVACI','DAVALI',
  'DURUSMATARIHI','KESIFTARIHI','KESIFSAATI','KESIFYERI','BILIRKISITARIHI',
  'KARARYILI','KARARNO','KARARTARIHI','KARAR','ACIKLAMA','SONISLEMTARIHI'
)
$Headers = @(
  'İşlem Türü','E.Yılı','E.No','Başkan','Tek Hakim','Dava Tarihi','Hdf','Hedef Tarih',
  'Dava Türü','UYAP Dava Türü','Dosya Durumu','Ele Al. Tar.','Davacı','Davalı',
  'Duruşma T.','Keşif Tarihi','Keşif Saati','Keşif Yeri','Bilirkişi Ver. T.',
  'K.Yıl','K.No','Karar Tarihi','Verilen Karar','UYAP Açıklaması','Son İşl. Tar.'
)
$DateFields = @('DAVATARIHI','HEDEFTARIH','ELEALINMATARIHI','DURUSMATARIHI','KESIFTARIHI','BILIRKISITARIHI','KARARTARIHI','SONISLEMTARIHI')

function Normalize-Value([object]$v) {
  if ($null -eq $v) { return '' }
  $s = [string]$v
  if ($s -eq '<null>') { return '' }
  return $s.TrimEnd()
}

function Get-RecordHash($record) {
  $parts = foreach ($f in $Fields) { Normalize-Value $record[$f] }
  $canonical = [string]::Join([char]31, $parts)
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($canonical)
    $hash = $sha.ComputeHash($bytes)
    return ([System.BitConverter]::ToString($hash)).Replace('-','').ToLowerInvariant()
  } finally { $sha.Dispose() }
}

function Get-Config {
  if (Test-Path $ConfigPath) {
    try { return Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
  }
  return $null
}

function Save-Config([string]$isql,[string]$gbak) {
  [ordered]@{ isql=$isql; gbak=$gbak } | ConvertTo-Json | Set-Content $ConfigPath -Encoding UTF8
}

function Test-FirebirdPair([string]$isql,[string]$gbak) {
  return ($isql -and $gbak -and (Test-Path -LiteralPath $isql) -and (Test-Path -LiteralPath $gbak))
}

function Find-Firebird([string]$fdbPath='') {
  $cfg = Get-Config
  if ($cfg -and (Test-FirebirdPair $cfg.isql $cfg.gbak)) {
    return @{ isql=[string]$cfg.isql; gbak=[string]$cfg.gbak }
  }

  $pairs = New-Object System.Collections.Generic.List[object]
  $portable = Join-Path $RuntimeDir 'firebird'
  $pairs.Add(@( (Join-Path $portable 'isql.exe'), (Join-Path $portable 'gbak.exe') ))

  foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if (-not $base) { continue }
    foreach ($sub in @('Firebird\Firebird_4_0','Firebird\Firebird_5_0','Firebird')) {
      $d = Join-Path $base $sub
      $pairs.Add(@( (Join-Path $d 'isql.exe'), (Join-Path $d 'gbak.exe') ))
    }
  }

  if ($fdbPath -and (Test-Path -LiteralPath $fdbPath)) {
    $d = Split-Path -Parent $fdbPath
    for ($i=0; $i -lt 4 -and $d; $i++) {
      foreach ($sub in @('', 'bin', 'firebird', 'Firebird', 'Firebird_4_0', 'Firebird_5_0')) {
        $cand = if ($sub) { Join-Path $d $sub } else { $d }
        $pairs.Add(@( (Join-Path $cand 'isql.exe'), (Join-Path $cand 'gbak.exe') ))
      }
      $parent = Split-Path -Parent $d
      if ($parent -eq $d) { break }
      $d = $parent
    }
  }

  foreach ($pair in $pairs) {
    if (Test-FirebirdPair $pair[0] $pair[1]) {
      Save-Config $pair[0] $pair[1]
      return @{ isql=$pair[0]; gbak=$pair[1] }
    }
  }
  return $null
}

function Download-Firebird {
  $dest = Join-Path $RuntimeDir 'firebird'
  if (Test-FirebirdPair (Join-Path $dest 'isql.exe') (Join-Path $dest 'gbak.exe')) {
    return @{ isql=(Join-Path $dest 'isql.exe'); gbak=(Join-Path $dest 'gbak.exe') }
  }
  $tmpZip = Join-Path ([System.IO.Path]::GetTempPath()) ('firebird_' + [guid]::NewGuid().ToString('N') + '.zip')
  $tmpDir = Join-Path ([System.IO.Path]::GetTempPath()) ('firebird_' + [guid]::NewGuid().ToString('N'))
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    (New-Object System.Net.WebClient).DownloadFile($FirebirdUrl, $tmpZip)
    New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
    Expand-Archive -LiteralPath $tmpZip -DestinationPath $tmpDir -Force
    $isql = Get-ChildItem -LiteralPath $tmpDir -Filter isql.exe -File -Recurse | Select-Object -First 1
    $gbak = Get-ChildItem -LiteralPath $tmpDir -Filter gbak.exe -File -Recurse | Select-Object -First 1
    if (-not $isql -or -not $gbak) { throw 'İndirilen Firebird paketinde isql.exe/gbak.exe bulunamadı.' }
    $src = $isql.Directory.FullName
    if (Test-Path $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
    Copy-Item -LiteralPath $src -Destination $dest -Recurse -Force
    $result = @{ isql=(Join-Path $dest 'isql.exe'); gbak=(Join-Path $dest 'gbak.exe') }
    if (-not (Test-FirebirdPair $result.isql $result.gbak)) { throw 'Firebird araçları kurulamadı.' }
    Save-Config $result.isql $result.gbak
    return $result
  } finally {
    Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
  }
}

function Ask-FirebirdFolder {
  $dlg = New-Object System.Windows.Forms.OpenFileDialog
  $dlg.Title = 'Firebird isql.exe dosyasını seçin'
  $dlg.Filter = 'isql.exe|isql.exe|EXE|*.exe'
  if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
  $isql = $dlg.FileName
  $gbak = Join-Path (Split-Path -Parent $isql) 'gbak.exe'
  if (-not (Test-Path -LiteralPath $gbak)) {
    [System.Windows.Forms.MessageBox]::Show('Seçtiğiniz klasörde gbak.exe bulunamadı. isql.exe ve gbak.exe aynı Firebird klasöründe olmalı.','Firebird') | Out-Null
    return $null
  }
  Save-Config $isql $gbak
  return @{ isql=$isql; gbak=$gbak }
}

function Ensure-Firebird([string]$fdbPath) {
  $fb = Find-Firebird $fdbPath
  if ($fb) { return $fb }
  $ans = [System.Windows.Forms.MessageBox]::Show(
    'Firebird okuma araçları bulunamadı. Program resmi Firebird 4.0.7 taşınabilir paketini otomatik indirsin mi? (Yaklaşık 23 MB)',
    'Firebird gerekli', [System.Windows.Forms.MessageBoxButtons]::YesNoCancel, [System.Windows.Forms.MessageBoxIcon]::Question)
  if ($ans -eq [System.Windows.Forms.DialogResult]::Yes) { return Download-Firebird }
  if ($ans -eq [System.Windows.Forms.DialogResult]::No) { return Ask-FirebirdFolder }
  return $null
}

function Decode-Output([string]$path) {
  $bytes = [System.IO.File]::ReadAllBytes($path)
  try {
    $utf8 = New-Object System.Text.UTF8Encoding($false,$true)
    return $utf8.GetString($bytes)
  } catch { return [System.Text.Encoding]::Default.GetString($bytes) }
}

function Parse-IsqlList([string]$path) {
  $text = Decode-Output $path
  $lines = $text -split "`r?`n"
  $known = @{}; foreach ($f in $Fields) { $known[$f]=$true }
  $records = New-Object System.Collections.Generic.List[object]
  $cur=@{}; $current=$null
  foreach ($line in $lines) {
    if ([string]::IsNullOrWhiteSpace($line)) {
      if ($cur.ContainsKey('ESASYILI') -and $cur.ContainsKey('ESASNO')) {
        $copy=@{}; foreach ($f in $Fields) { $copy[$f]=Normalize-Value $cur[$f] }
        $records.Add($copy)
      }
      $cur=@{}; $current=$null; continue
    }
    $prefixLen=[Math]::Min(32,$line.Length)
    $candidate=$line.Substring(0,$prefixLen).Trim()
    if ($known.ContainsKey($candidate)) {
      $value=if ($line.Length -gt 32) { $line.Substring(32).TrimStart() } else { '' }
      $cur[$candidate]=Normalize-Value $value
      $current=$candidate
    } elseif ($current -and $cur.ContainsKey($current)) {
      $cur[$current]=($cur[$current] + ' ' + $line.Trim()).Trim()
    }
  }
  if ($cur.ContainsKey('ESASYILI') -and $cur.ContainsKey('ESASNO')) {
    $copy=@{}; foreach ($f in $Fields) { $copy[$f]=Normalize-Value $cur[$f] }
    $records.Add($copy)
  }
  if ($records.Count -eq 0) { throw 'FDB içinden DOSYALAR kayıtları okunamadı.' }
  return ,$records.ToArray()
}

function Invoke-Process([string]$exe,[string[]]$args,[string]$working,[string]$out,[string]$err) {
  # Call operator passes each array element as one argument, so FDB paths containing spaces are safe.
  Push-Location $working
  try {
    & $exe @args 1> $out 2> $err
    $code = $LASTEXITCODE
  } finally { Pop-Location }
  $errText = if (Test-Path $err) { Decode-Output $err } else { '' }
  $outText = if (Test-Path $out) { Decode-Output $out } else { '' }
  if ($code -ne 0) {
    $tail = (($outText + "`n" + $errText) -split "`r?`n" | Select-Object -Last 15) -join "`r`n"
    throw "Firebird işlemi başarısız: $([IO.Path]::GetFileName($exe))`r`n$tail"
  }
}

function Extract-Fdb([string]$fdbPath,$fb) {
  if (-not (Test-Path -LiteralPath $fdbPath)) { throw 'FDB dosyası bulunamadı.' }
  if (-not (Test-Path -LiteralPath $QueryPath)) { throw 'query.sql bulunamadı.' }
  $temp = Join-Path ([IO.Path]::GetTempPath()) ('FDBTakip_' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $temp | Out-Null
  $backup=Join-Path $temp 'okuma.fbk'; $restore=Join-Path $temp 'okuma_restore.fdb'
  $o1=Join-Path $temp 'gbak1.out'; $e1=Join-Path $temp 'gbak1.err'; $o2=Join-Path $temp 'gbak2.out'; $e2=Join-Path $temp 'gbak2.err'
  $o3=Join-Path $temp 'isql.out'; $e3=Join-Path $temp 'isql.err'
  try {
    $fbDir = Split-Path -Parent $fb.gbak
    $oldFirebird=$env:FIREBIRD; $oldPath=$env:PATH
    $env:FIREBIRD=$fbDir; $env:PATH="$fbDir;$oldPath"
    try {
      Invoke-Process $fb.gbak @('-b','-g','-user','SYSDBA','-password','masterkey',$fdbPath,$backup) $fbDir $o1 $e1
      Invoke-Process $fb.gbak @('-c','-user','SYSDBA','-password','masterkey',$backup,$restore) $fbDir $o2 $e2
      Invoke-Process $fb.isql @('-q','-ch','UTF8','-user','SYSDBA','-password','masterkey',$restore,'-i',$QueryPath) $fbDir $o3 $e3
    } finally {
      $env:FIREBIRD=$oldFirebird; $env:PATH=$oldPath
    }
    return Parse-IsqlList $o3
  } finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
}

function Load-Baseline {
  $map=@{}
  if (-not (Test-Path -LiteralPath $BaselinePath)) { return $map }
  foreach ($line in Get-Content -LiteralPath $BaselinePath -Encoding UTF8) {
    if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith('#')) { continue }
    $p=$line -split "`t",2
    if ($p.Count -eq 2) { $map[$p[0]]=$p[1] }
  }
  return $map
}

function Get-State {
  try { if (Test-Path $StatePath) { return Get-Content $StatePath -Raw -Encoding UTF8 | ConvertFrom-Json } } catch {}
  return $null
}

function Get-MaxSonIslem($records) {
  $vals=@($records | ForEach-Object { Normalize-Value $_['SONISLEMTARIHI'] } | Where-Object { $_ })
  if ($vals.Count -eq 0) { return '' }
  return ($vals | Sort-Object | Select-Object -Last 1)
}

function Save-Baseline($records,[string]$source) {
  if (Test-Path $BaselinePath) {
    $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
    Copy-Item -LiteralPath $BaselinePath -Destination (Join-Path $HistoryDir "baseline_$stamp.tsv") -Force
    Get-ChildItem -LiteralPath $HistoryDir -Filter 'baseline_*.tsv' -File | Sort-Object LastWriteTime -Descending | Select-Object -Skip 10 | Remove-Item -Force -ErrorAction SilentlyContinue
  }
  $sb=New-Object System.Text.StringBuilder
  [void]$sb.AppendLine('# ESASYILI/ESASNO<TAB>SHA256')
  foreach ($r in $records) {
    $key="{0}/{1}" -f $r['ESASYILI'],$r['ESASNO']
    [void]$sb.Append($key).Append("`t").Append((Get-RecordHash $r)).AppendLine()
  }
  [IO.File]::WriteAllText($BaselinePath,$sb.ToString(),(New-Object Text.UTF8Encoding($false)))
  [ordered]@{
    known_count=$records.Count
    last_scan=(Get-Date).ToString('s')
    max_sonislem=(Get-MaxSonIslem $records)
    source=[IO.Path]::GetFileName($source)
    app_version=$AppVersion
  } | ConvertTo-Json | Set-Content $StatePath -Encoding UTF8
}

function Format-Field([string]$field,[object]$value) {
  $v=Normalize-Value $value
  if ($v -and ($DateFields -contains $field) -and $v.Length -ge 10 -and $v.Substring(4,1) -eq '-') {
    try { return ([datetime]::ParseExact($v.Substring(0,10),'yyyy-MM-dd',$null)).ToString('dd.MM.yyyy') } catch {}
  }
  return $v
}

function Xml-Escape([object]$v) {
  $s=if ($null -eq $v) { '' } else { [string]$v }
  $s=[regex]::Replace($s,'[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD]','')
  return [System.Security.SecurityElement]::Escape($s)
}

function Excel-Col([int]$n) {
  $s=''
  while ($n -gt 0) { $n--; $s=[char](65+($n%26))+$s; $n=[math]::Floor($n/26) }
  return $s
}

function Add-ZipText($zip,[string]$name,[string]$text) {
  $entry=$zip.CreateEntry($name,[IO.Compression.CompressionLevel]::Optimal)
  $stream=$entry.Open(); $writer=New-Object IO.StreamWriter($stream,(New-Object Text.UTF8Encoding($false)))
  try { $writer.Write($text) } finally { $writer.Dispose(); $stream.Dispose() }
}

function Export-Xlsx($changes,[string]$path) {
  $widths=@(15,9,9,22,22,13,8,13,26,40,28,13,38,42,13,13,12,28,15,9,9,13,30,42,13)
  $sb=New-Object Text.StringBuilder
  [void]$sb.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">')
  [void]$sb.Append('<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>')
  for ($i=0;$i -lt $widths.Count;$i++) { [void]$sb.Append("<col min=\"$($i+1)\" max=\"$($i+1)\" width=\"$($widths[$i])\" customWidth=\"1\"/>") }
  [void]$sb.Append('</cols><sheetData><row r="1" ht="28" customHeight="1">')
  for ($i=0;$i -lt $Headers.Count;$i++) {
    $ref=(Excel-Col ($i+1))+'1'; [void]$sb.Append("<c r=\"$ref\" t=\"inlineStr\" s=\"1\"><is><t xml:space=\"preserve\">$(Xml-Escape $Headers[$i])</t></is></c>")
  }
  [void]$sb.Append('</row>')
  $ri=2
  foreach ($item in $changes) {
    [void]$sb.Append("<row r=\"$ri\">")
    $vals=New-Object System.Collections.Generic.List[string]
    $vals.Add([string]$item.Operation)
    foreach ($f in $Fields) { $vals.Add((Format-Field $f $item.Record[$f])) }
    for ($ci=0;$ci -lt $vals.Count;$ci++) {
      $ref=(Excel-Col ($ci+1))+$ri; [void]$sb.Append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">$(Xml-Escape $vals[$ci])</t></is></c>")
    }
    [void]$sb.Append('</row>'); $ri++
  }
  [void]$sb.Append('</sheetData>')
  $last=(Excel-Col $Headers.Count); $lastRow=[Math]::Max(1,$ri-1)
  [void]$sb.Append("<autoFilter ref=\"A1:$last$lastRow\"/></worksheet>")
  $sheetXml=$sb.ToString()

  $types='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'
  $rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
  $wb='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Yeni-Güncellenen" sheetId="1" r:id="rId1"/></sheets></workbook>'
  $wbrels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
  $styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="10"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf></cellXfs></styleSheet>'

  if (Test-Path $path) { Remove-Item -LiteralPath $path -Force }
  $fs=[IO.File]::Open($path,[IO.FileMode]::CreateNew)
  $zip=New-Object IO.Compression.ZipArchive($fs,[IO.Compression.ZipArchiveMode]::Create,$false)
  try {
    Add-ZipText $zip '[Content_Types].xml' $types
    Add-ZipText $zip '_rels/.rels' $rels
    Add-ZipText $zip 'xl/workbook.xml' $wb
    Add-ZipText $zip 'xl/_rels/workbook.xml.rels' $wbrels
    Add-ZipText $zip 'xl/styles.xml' $styles
    Add-ZipText $zip 'xl/worksheets/sheet1.xml' $sheetXml
  } finally { $zip.Dispose(); $fs.Dispose() }
}

function Run-Scan([string]$fdbPath) {
  $fb=Ensure-Firebird $fdbPath
  if (-not $fb) { throw 'Firebird araçları seçilmedi.' }
  $records=Extract-Fdb $fdbPath $fb
  $state=Get-State; $currentMax=Get-MaxSonIslem $records

  # İlk çalıştırmada herhangi bir mahkeme verisi program paketinde taşınmaz.
  # Kullanıcının seçtiği ilk FDB yalnızca yerel başlangıç hafızasını oluşturur.
  if (-not (Test-Path -LiteralPath $BaselinePath)) {
    Save-Baseline $records $fdbPath
    return [pscustomobject]@{Initialized=$true; Total=$records.Count; New=0; Updated=0; Changes=0; Output=''; Max=$currentMax}
  }

  if ($state -and $state.max_sonislem -and $currentMax -and ([datetime]$currentMax -lt [datetime]$state.max_sonislem)) {
    throw "Seçilen FDB hafızadakinden daha eski görünüyor.`r`nHafızadaki son işlem: $($state.max_sonislem)`r`nSeçilen FDB: $currentMax`r`n`r`nHafıza geriye alınmadı."
  }
  if ($state -and $state.known_count -and $records.Count -lt ([int]$state.known_count * 0.80)) {
    throw "Seçilen FDB'de beklenenden çok daha az kayıt var ($($records.Count)). Yanlış/eski dosya ihtimaline karşı tarama durduruldu."
  }
  $base=Load-Baseline
  $changes=New-Object System.Collections.Generic.List[object]
  $newN=0; $updN=0
  foreach ($r in $records) {
    # DOSYALAR tablosunun gerçek birincil anahtarı ESASYILI + ESASNO'dur.
    $key="{0}/{1}" -f $r['ESASYILI'],$r['ESASNO']; $hash=Get-RecordHash $r
    if (-not $base.ContainsKey($key)) { $changes.Add([pscustomobject]@{Operation='YENİ';Record=$r}); $newN++ }
    elseif ($base[$key] -ne $hash) { $changes.Add([pscustomobject]@{Operation='GÜNCELLENDİ';Record=$r}); $updN++ }
  }
  $stamp=Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
  $out=Join-Path $OutDir "Yeni_Guncellenenler_$stamp.xlsx"
  Export-Xlsx $changes $out
  Save-Baseline $records $fdbPath
  return [pscustomobject]@{Initialized=$false; Total=$records.Count; New=$newN; Updated=$updN; Changes=$changes.Count; Output=$out; Max=$currentMax}
}

function State-Text {
  $s=Get-State
  if (-not $s -or -not (Test-Path -LiteralPath $BaselinePath)) { return 'Henüz başlangıç FDB'si tanıtılmadı.' }
  $count=('{0:N0}' -f [int]$s.known_count).Replace(',','.')
  return "Bilinen kayıt: $count    |    Son işlem: $($s.max_sonislem)    |    Son tarama: $($s.last_scan)"
}

# ---------------- GUI ----------------
$form=New-Object Windows.Forms.Form
$form.Text="FDB Takip $AppVersion"
$form.Size=New-Object Drawing.Size(790,535)
$form.StartPosition='CenterScreen'; $form.Font=New-Object Drawing.Font('Segoe UI',10); $form.MaximizeBox=$false

$title=New-Object Windows.Forms.Label
$title.Text='FDB TAKİP'; $title.Font=New-Object Drawing.Font('Segoe UI',20,[Drawing.FontStyle]::Bold); $title.AutoSize=$true; $title.Location=New-Object Drawing.Point(22,18); $form.Controls.Add($title)
$sub=New-Object Windows.Forms.Label
$sub.Text='Yeni ve güncellenen dosyaları tek Excel listesine çıkarır.'; $sub.AutoSize=$true; $sub.Location=New-Object Drawing.Point(25,58); $form.Controls.Add($sub)

$stateLabel=New-Object Windows.Forms.Label
$stateLabel.Text=State-Text; $stateLabel.AutoSize=$true; $stateLabel.Location=New-Object Drawing.Point(25,92); $form.Controls.Add($stateLabel)

$pathBox=New-Object Windows.Forms.TextBox
$pathBox.Location=New-Object Drawing.Point(25,130); $pathBox.Size=New-Object Drawing.Size(605,28); $form.Controls.Add($pathBox)
$selectBtn=New-Object Windows.Forms.Button
$selectBtn.Text='FDB Seç'; $selectBtn.Location=New-Object Drawing.Point(640,127); $selectBtn.Size=New-Object Drawing.Size(105,34); $form.Controls.Add($selectBtn)

$scanBtn=New-Object Windows.Forms.Button
$scanBtn.Text='TARA VE KARŞILAŞTIR'; $scanBtn.Location=New-Object Drawing.Point(25,178); $scanBtn.Size=New-Object Drawing.Size(210,45); $scanBtn.Font=New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold); $form.Controls.Add($scanBtn)
$openBtn=New-Object Windows.Forms.Button
$openBtn.Text='Çıktı Klasörü'; $openBtn.Location=New-Object Drawing.Point(250,178); $openBtn.Size=New-Object Drawing.Size(145,45); $form.Controls.Add($openBtn)

$progress=New-Object Windows.Forms.ProgressBar
$progress.Location=New-Object Drawing.Point(25,240); $progress.Size=New-Object Drawing.Size(720,20); $progress.Style='Marquee'; $progress.MarqueeAnimationSpeed=0; $form.Controls.Add($progress)

$status=New-Object Windows.Forms.Label
$status.Text='Hazır'; $status.AutoSize=$true; $status.Location=New-Object Drawing.Point(25,270); $form.Controls.Add($status)

$result=New-Object Windows.Forms.TextBox
$result.Location=New-Object Drawing.Point(25,300); $result.Size=New-Object Drawing.Size(720,145); $result.Multiline=$true; $result.ReadOnly=$true; $result.ScrollBars='Vertical'; $form.Controls.Add($result)
$foot=New-Object Windows.Forms.Label
$foot.Text='Kaynak FDB üzerinde yazma yapılmaz. Okuma, Firebird yedeği + geçici geri yükleme üzerinden yapılır.'; $foot.AutoSize=$true; $foot.Location=New-Object Drawing.Point(25,460); $form.Controls.Add($foot)

$selectBtn.Add_Click({
  $dlg=New-Object Windows.Forms.OpenFileDialog; $dlg.Title='Güncel DOSYATKP FDB dosyasını seçin'; $dlg.Filter='Firebird Database (*.fdb)|*.fdb|Tüm dosyalar|*.*'
  if ($dlg.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) { $pathBox.Text=$dlg.FileName; $result.Clear() }
})
$openBtn.Add_Click({ Start-Process explorer.exe $OutDir })
$scanBtn.Add_Click({
  if (-not (Test-Path -LiteralPath $pathBox.Text)) { [Windows.Forms.MessageBox]::Show('Önce güncel .FDB dosyasını seçin.','FDB Takip') | Out-Null; return }
  try {
    $scanBtn.Enabled=$false; $selectBtn.Enabled=$false; $progress.MarqueeAnimationSpeed=30; $status.Text='FDB okunuyor ve hafızayla karşılaştırılıyor...'; $result.Clear(); [Windows.Forms.Application]::DoEvents()
    $res=Run-Scan $pathBox.Text
    $stateLabel.Text=State-Text; $status.Text='Tarama tamamlandı'
    if ($res.Initialized) {
      $result.Text=("Başlangıç hafızası oluşturuldu.`r`nToplam kayıt: {0}`r`n`r`nBu FDB baz alındı. Bir sonraki güncel FDB'de yalnızca yeni veya değişen dosyalar çıkarılacak." -f $res.Total)
      [Windows.Forms.MessageBox]::Show(("Başlangıç hafızası oluşturuldu: {0} kayıt.`r`n`r`nSonraki FDB taramasında değişiklikler karşılaştırılacak." -f $res.Total),'Başlangıç hazır',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    } else {
      $result.Text=("Toplam kayıt: {0}`r`nYeni: {1}`r`nGüncellenen: {2}`r`nYeni/Güncellenen toplam: {3}`r`n`r`nExcel: {4}" -f $res.Total,$res.New,$res.Updated,$res.Changes,$res.Output)
      [Windows.Forms.MessageBox]::Show(("Yeni/Güncellenen: {0}`r`n`r`nExcel oluşturuldu." -f $res.Changes),'Tamamlandı',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    }
  } catch {
    $status.Text='Tarama başarısız'; $result.Text=$_.Exception.Message
    [Windows.Forms.MessageBox]::Show($_.Exception.Message,'Hata',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error) | Out-Null
  } finally { $progress.MarqueeAnimationSpeed=0; $scanBtn.Enabled=$true; $selectBtn.Enabled=$true }
})
[void]$form.ShowDialog()
