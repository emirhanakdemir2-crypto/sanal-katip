# FDB Takip

`DOSYATKP.FDB` içindeki dosya kayıtlarını salt-okuma mantığıyla okuyup önceki taramayla karşılaştırır.

## Amaç

- İlk FDB → başlangıç hafızası
- Sonraki FDB → değişmeyenleri atla
- **Yeni + güncellenenleri tek listede** çıkar
- Sonucu `.xlsx` olarak oluştur

Takip edilen alanlar: E.Yılı, E.No, Başkan, Tek Hakim, Dava Tarihi, Hdf/Hedef Süre, Hedef Tarih, Dava Türü, UYAP Dava Türü, Dosya Durumu, Ele Alınma Tarihi, Davacı, Davalı, Duruşma Tarihi, Keşif Tarihi/Saati/Yeri, Bilirkişi Tarihi, Karar Yılı/No/Tarihi, Verilen Karar, UYAP Açıklaması ve Son İşlem Tarihi.

## İki yol

### `uipath/`
Kurum bilgisayarı için ana yol. Mevcut UiPath projenizle aynı Studio/`UiPath.System.Activities` sürüm ailesine göre hazırlanmıştır. `project.json` açılır ve `Main.xaml` çalıştırılır. PowerShell kullanılmaz.

### `windows-source/`
Bağımsız Windows uygulamasının .NET 8 kaynak kodu. Kurum güvenlik politikasını aşmak için değil, izin verilen geliştirme bilgisayarında derlemek için tutulur.

## Veri güvenliği

Bu repoda **FDB, Excel, taraf isimleri veya başlangıç verisi bulunmaz**. `.gitignore` bunları dışlar. Kaynak FDB'ye yazma yapılmaz; geçici yedek/geri-yükleme kopyası üzerinden okunur.
