# Bağımsız Windows kaynak sürümü

Bu klasör bağımsız Windows uygulamasının kaynak kodudur. Kurum bilgisayarında güvenlik politikalarını aşmak için kullanılmaz.

Geliştirme/izin verilen bir bilgisayarda .NET 8 SDK ile derlenebilir:

```text
dotnet publish -c Release -r win-x64 --self-contained false
```

Kurum bilgisayarı indirilen veya imzasız EXE'leri engelliyorsa bu engel devre dışı bırakılmamalıdır. Kurum PC'sinde `uipath/` sürümü tercih edilir.
