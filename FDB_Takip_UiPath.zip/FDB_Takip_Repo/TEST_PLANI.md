# Kabul testi

1. İlk çalıştırmada mevcut FDB seçilir.
   - Beklenen: tüm kayıtlar başlangıç hafızasına alınır.
   - Excel oluşturulmaz.
2. Aynı FDB tekrar seçilir.
   - Beklenen: `Yeni/Güncellenen: 0`.
3. Daha güncel FDB seçilir.
   - Beklenen: yalnız yeni esaslar ve mevcut olup izlenen alanlarından en az biri değişmiş esaslar tek Excel'de çıkar.
4. Daha eski görünen FDB seçilir.
   - Beklenen: mevcut hafıza korunur ve tarama durur.

Çıktı Excel'i `Belgeler\\FDB Takip Ciktilari` altına yazılır.
Yerel takip hafızası `%LOCALAPPDATA%\\FDBTakipUiPath` altında tutulur.
