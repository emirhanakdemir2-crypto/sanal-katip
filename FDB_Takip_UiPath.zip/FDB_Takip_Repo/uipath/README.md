# UiPath sürümü

Bu klasör kurum bilgisayarında **UiPath Studio** ile açılacak sürümdür.

## Kullanım

1. Bu klasörü bilgisayara indirin.
2. UiPath Studio → **Open / Local Project** ile `project.json` dosyasını açın.
3. Paket geri yükleme tamamlanınca `Main.xaml` açılır.
4. **Run File / Çalıştır** deyin.
5. Açılan pencereden `.FDB` dosyasını seçin.

İlk çalıştırma seçilen FDB'yi yerel başlangıç hafızası yapar. Sonraki çalıştırmalarda yalnız **YENİ + GÜNCELLENDİ** kayıtları tek Excel dosyasına çıkarılır.

Çıktı klasörü:

`Belgeler\FDB Takip Ciktilari`

Yerel hafıza:

`%LOCALAPPDATA%\FDBTakipUiPath`

## Firebird araçları

Workflow `gbak.exe` ve `isql.exe` araçlarını sistemde otomatik arar. Bulamazsa bir kere `gbak.exe` seçmenizi ister; aynı klasörde `isql.exe` de bulunmalıdır. Araçların klasörü yalnız yerel bilgisayarda hatırlanır.

## Güvenlik

- FDB'ye veri yazılmaz.
- Okuma, `gbak` yedeği + geçici geri yükleme üzerinden yapılır.
- Eski görünen bir FDB seçilirse mevcut hafıza güncellenmez.
- FDB, Excel veya taraf bilgisi GitHub'a yüklenmez.
