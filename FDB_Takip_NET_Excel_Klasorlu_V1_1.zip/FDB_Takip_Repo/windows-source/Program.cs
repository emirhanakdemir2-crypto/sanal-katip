using System;

namespace FDBTakip;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        // UiPath Invoke Code (C#) method body.
        // No FDB content is embedded. The selected FDB is read through local Firebird gbak/isql tools.
        
        string[] fields = new string[] {
            "ESASYILI","ESASNO","BASKAN","TEKHAKIM","DAVATARIHI","HEDEFSURE","HEDEFTARIH",
            "DAVATURU","UYAPDAVATURU","DOSYADURUMU","ELEALINMATARIHI","DAVACI","DAVALI",
            "DURUSMATARIHI","KESIFTARIHI","KESIFSAATI","KESIFYERI","BILIRKISITARIHI",
            "KARARYILI","KARARNO","KARARTARIHI","KARAR","ACIKLAMA","SONISLEMTARIHI"
        };
        
        string[] headers = new string[] {
            "E.Yılı","E.No","Başkan","Tek Hakim","Dava Tarihi","Hdf","Hedef Tarih",
            "Dava Türü","UYAP Dava Türü","Dosya Durumu","Ele Al. Tar.","Davacı","Davalı",
            "Duruşma T.","Keşif Tarihi","Keşif Saati","Keşif Yeri","Bilirkişi Ver. T.",
            "K.Yıl","K.No","Karar Tarihi","Verilen Karar","UYAP Açıklaması","Son İşl. Tar."
        };
        
        string query = @"SET LIST ON;
        SET COUNT OFF;
        SELECT
          D.ESASYILI AS ESASYILI,
          D.ESASNO AS ESASNO,
          REPLACE(REPLACE(HB.ADISOYADI, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS BASKAN,
          REPLACE(REPLACE(HT.ADISOYADI, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS TEKHAKIM,
          D.DAVATARIHI AS DAVATARIHI,
          D.HEDEFSURE AS HEDEFSURE,
          D.HEDEFTARIH AS HEDEFTARIH,
          REPLACE(REPLACE(DT.DAVATURU, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS DAVATURU,
          REPLACE(REPLACE(D.UYAPDAVATURU, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS UYAPDAVATURU,
          REPLACE(REPLACE(DD.DOSYADURUMU, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS DOSYADURUMU,
          D.ELEALINMATARIHI AS ELEALINMATARIHI,
          REPLACE(REPLACE(D.DAVACI, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS DAVACI,
          REPLACE(REPLACE(D.DAVALI, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS DAVALI,
          D.DURUSMATARIHI AS DURUSMATARIHI,
          D.KESIFTARIHI AS KESIFTARIHI,
          D.KESIFSAATI AS KESIFSAATI,
          REPLACE(REPLACE(D.KESIFYERI, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS KESIFYERI,
          D.BILIRKISITARIHI AS BILIRKISITARIHI,
          D.KARARYILI AS KARARYILI,
          D.KARARNO AS KARARNO,
          D.KARARTARIHI AS KARARTARIHI,
          REPLACE(REPLACE(D.KARAR, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS KARAR,
          REPLACE(REPLACE(D.ACIKLAMA, ASCII_CHAR(13), ' '), ASCII_CHAR(10), ' ') AS ACIKLAMA,
          D.SONISLEMTARIHI AS SONISLEMTARIHI
        FROM DOSYALAR D
        LEFT JOIN HAKIMLER HB ON HB.SICILNO = D.BASKANSICNO
        LEFT JOIN HAKIMLER HT ON HT.SICILNO = D.TEKHAKIMSICNO
        LEFT JOIN DAVATURU DT ON DT.DAVATURKODU = D.DAVATURKODU
        LEFT JOIN DOSYADURUMU DD ON DD.DOSYADURUMKODU = D.DOSYADURUMKODU
        ORDER BY D.ESASYILI, D.ESASNO;
        QUIT;";
        
        string NormalizeValue(string value)
        {
            if (value == null || value == "<null>") return "";
            return value.TrimEnd();
        }
        
        string PickFile(string title, string filter, string fileName)
        {
            string selected = "";
            System.Exception pickerError = null;
            var thread = new System.Threading.Thread(() =>
            {
                try
                {
                    var dlg = new Microsoft.Win32.OpenFileDialog();
                    dlg.Title = title;
                    dlg.Filter = filter;
                    dlg.FileName = fileName ?? "";
                    dlg.Multiselect = false;
                    bool? result = dlg.ShowDialog();
                    if (result == true) selected = dlg.FileName;
                }
                catch (System.Exception ex) { pickerError = ex; }
            });
            thread.SetApartmentState(System.Threading.ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (pickerError != null) throw pickerError;
            return selected;
        }
        
        void ShowMessage(string text, string title)
        {
            System.Exception messageError = null;
            var thread = new System.Threading.Thread(() =>
            {
                try { System.Windows.MessageBox.Show(text, title); }
                catch (System.Exception ex) { messageError = ex; }
            });
            thread.SetApartmentState(System.Threading.ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (messageError != null) System.Console.WriteLine(title + ": " + text);
        }
        
        bool IsFirebirdFolder(string folder)
        {
            if (string.IsNullOrWhiteSpace(folder)) return false;
            return System.IO.File.Exists(System.IO.Path.Combine(folder, "gbak.exe")) &&
                   System.IO.File.Exists(System.IO.Path.Combine(folder, "isql.exe"));
        }
        
        string FindFirebirdFolder(string fdbPath, string configPath)
        {
            try
            {
                if (System.IO.File.Exists(configPath))
                {
                    string saved = System.IO.File.ReadAllText(configPath, System.Text.Encoding.UTF8).Trim();
                    if (IsFirebirdFolder(saved)) return saved;
                }
            }
            catch { }
        
            var candidates = new System.Collections.Generic.List<string>();
            string pf = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles);
            string pfx86 = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFilesX86);
        
            foreach (string baseDir in new string[] { pf, pfx86 })
            {
                if (string.IsNullOrWhiteSpace(baseDir)) continue;
                candidates.Add(System.IO.Path.Combine(baseDir, "Firebird", "Firebird_5_0"));
                candidates.Add(System.IO.Path.Combine(baseDir, "Firebird", "Firebird_4_0"));
                candidates.Add(System.IO.Path.Combine(baseDir, "Firebird", "Firebird_3_0"));
                candidates.Add(System.IO.Path.Combine(baseDir, "Firebird"));
            }
        
            string dir = System.IO.Path.GetDirectoryName(fdbPath);
            for (int i = 0; i < 5 && !string.IsNullOrWhiteSpace(dir); i++)
            {
                candidates.Add(dir);
                candidates.Add(System.IO.Path.Combine(dir, "bin"));
                candidates.Add(System.IO.Path.Combine(dir, "Firebird"));
                candidates.Add(System.IO.Path.Combine(dir, "firebird"));
                string parent = System.IO.Directory.GetParent(dir) == null ? "" : System.IO.Directory.GetParent(dir).FullName;
                if (parent == dir) break;
                dir = parent;
            }
        
            foreach (string candidate in candidates)
            {
                if (IsFirebirdFolder(candidate)) return candidate;
            }
        
            // Lightweight recursive scan only under Firebird-like directories in Program Files.
            foreach (string baseDir in new string[] { pf, pfx86 })
            {
                if (string.IsNullOrWhiteSpace(baseDir) || !System.IO.Directory.Exists(baseDir)) continue;
                try
                {
                    foreach (string d in System.IO.Directory.GetDirectories(baseDir, "*Firebird*", System.IO.SearchOption.TopDirectoryOnly))
                    {
                        if (IsFirebirdFolder(d)) return d;
                        try
                        {
                            foreach (string sub in System.IO.Directory.GetDirectories(d, "*", System.IO.SearchOption.AllDirectories))
                            {
                                if (IsFirebirdFolder(sub)) return sub;
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
        
            return "";
        }
        
        string RunProcess(string exe, System.Collections.Generic.IEnumerable<string> args, string workingDir)
        {
            var psi = new System.Diagnostics.ProcessStartInfo();
            psi.FileName = exe;
            psi.WorkingDirectory = workingDir;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = new System.Text.UTF8Encoding(false);
            psi.StandardErrorEncoding = new System.Text.UTF8Encoding(false);
            foreach (string arg in args) psi.ArgumentList.Add(arg);
        
            using (var p = new System.Diagnostics.Process())
            {
                p.StartInfo = psi;
                p.Start();
                string stdout = p.StandardOutput.ReadToEnd();
                string stderr = p.StandardError.ReadToEnd();
                p.WaitForExit();
                if (p.ExitCode != 0)
                {
                    string combined = (stdout + "\n" + stderr).Trim();
                    if (combined.Length > 3000) combined = combined.Substring(combined.Length - 3000);
                    throw new System.Exception(System.IO.Path.GetFileName(exe) + " başarısız oldu.\n" + combined);
                }
                return stdout;
            }
        }
        
        System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,string>> ParseIsql(string text)
        {
            var known = new System.Collections.Generic.HashSet<string>(fields, System.StringComparer.OrdinalIgnoreCase);
            var records = new System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,string>>();
            var current = new System.Collections.Generic.Dictionary<string,string>(System.StringComparer.OrdinalIgnoreCase);
            string currentField = "";
            string[] lines = text.Replace("\r\n", "\n").Replace("\r", "\n").Split('\n');
        
            foreach (string raw in lines)
            {
                string line = raw ?? "";
                if (string.IsNullOrWhiteSpace(line))
                {
                    if (current.ContainsKey("ESASYILI") && current.ContainsKey("ESASNO"))
                    {
                        var copy = new System.Collections.Generic.Dictionary<string,string>(System.StringComparer.OrdinalIgnoreCase);
                        foreach (string f in fields) copy[f] = current.ContainsKey(f) ? NormalizeValue(current[f]) : "";
                        records.Add(copy);
                    }
                    current = new System.Collections.Generic.Dictionary<string,string>(System.StringComparer.OrdinalIgnoreCase);
                    currentField = "";
                    continue;
                }
        
                int prefixLen = System.Math.Min(32, line.Length);
                string candidate = line.Substring(0, prefixLen).Trim();
                if (known.Contains(candidate))
                {
                    string value = line.Length > 32 ? line.Substring(32).TrimStart() : "";
                    current[candidate] = NormalizeValue(value);
                    currentField = candidate;
                }
                else if (!string.IsNullOrEmpty(currentField) && current.ContainsKey(currentField))
                {
                    current[currentField] = (current[currentField] + " " + line.Trim()).Trim();
                }
            }
        
            if (current.ContainsKey("ESASYILI") && current.ContainsKey("ESASNO"))
            {
                var copy = new System.Collections.Generic.Dictionary<string,string>(System.StringComparer.OrdinalIgnoreCase);
                foreach (string f in fields) copy[f] = current.ContainsKey(f) ? NormalizeValue(current[f]) : "";
                records.Add(copy);
            }
        
            if (records.Count == 0) throw new System.Exception("FDB içinden DOSYALAR kayıtları okunamadı.");
            return records;
        }
        
        string Canonical(System.Collections.Generic.Dictionary<string,string> record)
        {
            var values = new string[fields.Length];
            for (int i = 0; i < fields.Length; i++) values[i] = record.ContainsKey(fields[i]) ? NormalizeValue(record[fields[i]]) : "";
            return string.Join("\u001F", values);
        }
        
        string KeyOf(System.Collections.Generic.Dictionary<string,string> record)
        {
            return NormalizeValue(record["ESASYILI"]) + "/" + NormalizeValue(record["ESASNO"]);
        }
        
        System.Collections.Generic.Dictionary<string,string> LoadBaseline(string path)
        {
            var result = new System.Collections.Generic.Dictionary<string,string>(System.StringComparer.OrdinalIgnoreCase);
            if (!System.IO.File.Exists(path)) return result;
            foreach (string line in System.IO.File.ReadAllLines(path, System.Text.Encoding.UTF8))
            {
                if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#")) continue;
                int tab = line.IndexOf('\t');
                if (tab <= 0) continue;
                string key = line.Substring(0, tab);
                string b64 = line.Substring(tab + 1);
                try
                {
                    string canonical = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(b64));
                    result[key] = canonical;
                }
                catch { }
            }
            return result;
        }
        
        void SaveBaseline(string path, System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,string>> records)
        {
            string tmp = path + ".tmp";
            using (var sw = new System.IO.StreamWriter(tmp, false, new System.Text.UTF8Encoding(false)))
            {
                sw.WriteLine("# FDB Takip UiPath baseline v1");
                foreach (var record in records)
                {
                    string key = KeyOf(record);
                    string b64 = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(Canonical(record)));
                    sw.Write(key); sw.Write('\t'); sw.WriteLine(b64);
                }
            }
            if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
            System.IO.File.Move(tmp, path);
        }
        
        string MaxSonIslem(System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,string>> records)
        {
            string max = "";
            foreach (var record in records)
            {
                string v = record.ContainsKey("SONISLEMTARIHI") ? NormalizeValue(record["SONISLEMTARIHI"]) : "";
                if (!string.IsNullOrEmpty(v) && string.CompareOrdinal(v, max) > 0) max = v;
            }
            return max;
        }
        
        string ChangedFields(string oldCanonical, System.Collections.Generic.Dictionary<string,string> current)
        {
            string[] oldValues = oldCanonical.Split(new char[] { '\u001F' });
            var changed = new System.Collections.Generic.List<string>();
            for (int i = 0; i < fields.Length; i++)
            {
                string oldValue = i < oldValues.Length ? NormalizeValue(oldValues[i]) : "";
                string newValue = current.ContainsKey(fields[i]) ? NormalizeValue(current[fields[i]]) : "";
                if (!string.Equals(oldValue, newValue, System.StringComparison.Ordinal)) changed.Add(headers[i]);
            }
            return string.Join(", ", changed);
        }
        
        string XmlEscape(string value)
        {
            if (value == null) return "";
            return value.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;").Replace("'", "&apos;");
        }
        
        string ExcelColumn(int oneBased)
        {
            string s = "";
            int n = oneBased;
            while (n > 0)
            {
                n--;
                s = ((char)('A' + (n % 26))).ToString() + s;
                n /= 26;
            }
            return s;
        }
        
        void WriteZipText(System.IO.Compression.ZipArchive zip, string entryName, string content)
        {
            var entry = zip.CreateEntry(entryName, System.IO.Compression.CompressionLevel.Optimal);
            using (var stream = entry.Open())
            using (var writer = new System.IO.StreamWriter(stream, new System.Text.UTF8Encoding(false))) writer.Write(content);
        }
        
        void WriteXlsx(string path, System.Collections.Generic.List<System.Tuple<string,string,System.Collections.Generic.Dictionary<string,string>>> changes)
        {
            string[] outHeaders = new string[headers.Length + 2];
            outHeaders[0] = "İşlem Türü";
            outHeaders[1] = "Değişen Alanlar";
            for (int i = 0; i < headers.Length; i++) outHeaders[i + 2] = headers[i];
        
            var sb = new System.Text.StringBuilder();
            sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
            sb.Append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
            sb.Append("<cols>");
            for (int i = 1; i <= outHeaders.Length; i++)
            {
                double width = (i == 1 ? 15 : (i == 2 ? 38 : (i == 14 || i == 15 || i == 24 || i == 25 ? 42 : 18)));
                sb.Append("<col min=\"").Append(i).Append("\" max=\"").Append(i).Append("\" width=\"").Append(width.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\" customWidth=\"1\"/>");
            }
            sb.Append("</cols><sheetData>");
        
            sb.Append("<row r=\"1\">");
            for (int c = 0; c < outHeaders.Length; c++)
            {
                string cell = ExcelColumn(c + 1) + "1";
                sb.Append("<c r=\"").Append(cell).Append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").Append(XmlEscape(outHeaders[c])).Append("</t></is></c>");
            }
            sb.Append("</row>");
        
            int rowNo = 2;
            foreach (var change in changes)
            {
                var vals = new string[outHeaders.Length];
                vals[0] = change.Item1;
                vals[1] = change.Item2;
                for (int i = 0; i < fields.Length; i++) vals[i + 2] = change.Item3.ContainsKey(fields[i]) ? NormalizeValue(change.Item3[fields[i]]) : "";
                sb.Append("<row r=\"").Append(rowNo).Append("\">");
                for (int c = 0; c < vals.Length; c++)
                {
                    string cell = ExcelColumn(c + 1) + rowNo.ToString();
                    sb.Append("<c r=\"").Append(cell).Append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").Append(XmlEscape(vals[c])).Append("</t></is></c>");
                }
                sb.Append("</row>");
                rowNo++;
            }
            sb.Append("</sheetData><autoFilter ref=\"A1:").Append(ExcelColumn(outHeaders.Length)).Append((rowNo - 1).ToString()).Append("\"/></worksheet>");
        
            string contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>";
            string rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";
            string workbook = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Yeni-Güncellenen\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
            string wbRels = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>";
        
            if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
            using (var fs = new System.IO.FileStream(path, System.IO.FileMode.CreateNew, System.IO.FileAccess.ReadWrite, System.IO.FileShare.None))
            using (var zip = new System.IO.Compression.ZipArchive(fs, System.IO.Compression.ZipArchiveMode.Create))
            {
                WriteZipText(zip, "[Content_Types].xml", contentTypes);
                WriteZipText(zip, "_rels/.rels", rootRels);
                WriteZipText(zip, "xl/workbook.xml", workbook);
                WriteZipText(zip, "xl/_rels/workbook.xml.rels", wbRels);
                WriteZipText(zip, "xl/worksheets/sheet1.xml", sb.ToString());
            }
        }
        

        void WriteAllXlsx(string path, System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,string>> records)
        {
            var sb = new System.Text.StringBuilder();
            sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
            sb.Append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
            sb.Append("<cols>");
            for (int i = 1; i <= headers.Length; i++)
            {
                double width = (i == 9 || i == 12 || i == 13 || i == 22 || i == 23 ? 42 : 18);
                sb.Append("<col min=\"").Append(i).Append("\" max=\"").Append(i).Append("\" width=\"").Append(width.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\" customWidth=\"1\"/>");
            }
            sb.Append("</cols><sheetData>");

            sb.Append("<row r=\"1\">");
            for (int c = 0; c < headers.Length; c++)
            {
                string cell = ExcelColumn(c + 1) + "1";
                sb.Append("<c r=\"").Append(cell).Append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").Append(XmlEscape(headers[c])).Append("</t></is></c>");
            }
            sb.Append("</row>");

            int rowNo = 2;
            foreach (var record in records)
            {
                sb.Append("<row r=\"").Append(rowNo).Append("\">");
                for (int c = 0; c < fields.Length; c++)
                {
                    string cell = ExcelColumn(c + 1) + rowNo.ToString();
                    string value = record.ContainsKey(fields[c]) ? NormalizeValue(record[fields[c]]) : "";
                    sb.Append("<c r=\"").Append(cell).Append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").Append(XmlEscape(value)).Append("</t></is></c>");
                }
                sb.Append("</row>");
                rowNo++;
            }
            sb.Append("</sheetData><autoFilter ref=\"A1:").Append(ExcelColumn(headers.Length)).Append((rowNo - 1).ToString()).Append("\"/></worksheet>");

            string contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>";
            string rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";
            string workbook = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Tüm Kayıtlar\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
            string wbRels = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>";

            if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
            using (var fs = new System.IO.FileStream(path, System.IO.FileMode.CreateNew, System.IO.FileAccess.ReadWrite, System.IO.FileShare.None))
            using (var zip = new System.IO.Compression.ZipArchive(fs, System.IO.Compression.ZipArchiveMode.Create))
            {
                WriteZipText(zip, "[Content_Types].xml", contentTypes);
                WriteZipText(zip, "_rels/.rels", rootRels);
                WriteZipText(zip, "xl/workbook.xml", workbook);
                WriteZipText(zip, "xl/_rels/workbook.xml.rels", wbRels);
                WriteZipText(zip, "xl/worksheets/sheet1.xml", sb.ToString());
            }
        }

        try
        {
            string fdbPath = PickFile("Güncel DOSYATKP.FDB dosyasını seçin", "Firebird veritabanı (*.FDB)|*.FDB|Tüm dosyalar (*.*)|*.*", "");
            if (string.IsNullOrWhiteSpace(fdbPath)) return;
        
            string dataDir = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData), "FDBTakipUiPath");
            string historyDir = System.IO.Path.Combine(dataDir, "history");
            string outDir = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments), "FDB Takip Ciktilari");
            System.IO.Directory.CreateDirectory(dataDir);
            System.IO.Directory.CreateDirectory(historyDir);
            System.IO.Directory.CreateDirectory(outDir);
        
            string baselinePath = System.IO.Path.Combine(dataDir, "baseline.tsv");
            string statePath = System.IO.Path.Combine(dataDir, "state.txt");
            string firebirdConfig = System.IO.Path.Combine(dataDir, "firebird_dir.txt");
        
            string fbDir = FindFirebirdFolder(fdbPath, firebirdConfig);
            if (string.IsNullOrWhiteSpace(fbDir))
            {
                ShowMessage("Firebird okuma araçları otomatik bulunamadı. Bir kez gbak.exe dosyasını seçin. Aynı klasörde isql.exe de bulunmalı.", "FDB Takip");
                string gbakSelected = PickFile("Firebird gbak.exe dosyasını seçin", "gbak.exe|gbak.exe|EXE (*.exe)|*.exe", "gbak.exe");
                if (string.IsNullOrWhiteSpace(gbakSelected)) return;
                fbDir = System.IO.Path.GetDirectoryName(gbakSelected);
                if (!IsFirebirdFolder(fbDir)) throw new System.Exception("Seçilen klasörde hem gbak.exe hem isql.exe bulunamadı.");
                System.IO.File.WriteAllText(firebirdConfig, fbDir, new System.Text.UTF8Encoding(false));
            }
        
            string gbak = System.IO.Path.Combine(fbDir, "gbak.exe");
            string isql = System.IO.Path.Combine(fbDir, "isql.exe");
        
            string tempDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FDBTakipUiPath_" + System.Guid.NewGuid().ToString("N"));
            System.IO.Directory.CreateDirectory(tempDir);
            System.Collections.Generic.List<System.Collections.Generic.Dictionary<string,string>> records;
            try
            {
                string backup = System.IO.Path.Combine(tempDir, "readcopy.fbk");
                string restored = System.IO.Path.Combine(tempDir, "readcopy.fdb");
                string queryPath = System.IO.Path.Combine(tempDir, "query.sql");
                System.IO.File.WriteAllText(queryPath, query, new System.Text.UTF8Encoding(false));
        
                RunProcess(gbak, new string[] { "-b", "-g", "-user", "SYSDBA", "-password", "masterkey", fdbPath, backup }, fbDir);
                RunProcess(gbak, new string[] { "-c", "-user", "SYSDBA", "-password", "masterkey", backup, restored }, fbDir);
                string isqlOutput = RunProcess(isql, new string[] { "-q", "-ch", "UTF8", "-user", "SYSDBA", "-password", "masterkey", restored, "-i", queryPath }, fbDir);
                records = ParseIsql(isqlOutput);
            }
            finally
            {
                try { if (System.IO.Directory.Exists(tempDir)) System.IO.Directory.Delete(tempDir, true); } catch { }
            }
        
            string allOutputPath = System.IO.Path.Combine(outDir, "Tum_Kayitlar.xlsx");
            WriteAllXlsx(allOutputPath, records);

            string currentMax = MaxSonIslem(records);
            string previousMax = System.IO.File.Exists(statePath) ? System.IO.File.ReadAllText(statePath, System.Text.Encoding.UTF8).Trim() : "";
            if (!string.IsNullOrWhiteSpace(previousMax) && !string.IsNullOrWhiteSpace(currentMax) && string.CompareOrdinal(currentMax, previousMax) < 0)
            {
                throw new System.Exception("Seçilen FDB, daha önce işlenen FDB'den eski görünüyor. Hafıza korunarak işlem durduruldu.\nÖnceki son işlem: " + previousMax + "\nSeçilen FDB son işlem: " + currentMax);
            }
        
            var baseline = LoadBaseline(baselinePath);
            if (baseline.Count == 0)
            {
                SaveBaseline(baselinePath, records);
                System.IO.File.WriteAllText(statePath, currentMax, new System.Text.UTF8Encoding(false));
                ShowMessage("İlk tarama tamamlandı. " + records.Count.ToString("N0") + " kayıt başlangıç hafızasına alındı.\n\nTüm kayıtlar Excel:\n" + allOutputPath + "\n\nBundan sonraki FDB'lerde yalnız yeni veya değişen dosyalar ayrıca çıkarılacak.", "FDB Takip");
                try
                {
                    var psi = new System.Diagnostics.ProcessStartInfo("explorer.exe", "/select,\"" + allOutputPath + "\"");
                    psi.UseShellExecute = true;
                    System.Diagnostics.Process.Start(psi);
                }
                catch { }
                return;
            }
        
            var changes = new System.Collections.Generic.List<System.Tuple<string,string,System.Collections.Generic.Dictionary<string,string>>>();
            foreach (var record in records)
            {
                string key = KeyOf(record);
                string currentCanonical = Canonical(record);
                if (!baseline.ContainsKey(key))
                {
                    changes.Add(System.Tuple.Create("YENİ", "", record));
                }
                else if (!string.Equals(baseline[key], currentCanonical, System.StringComparison.Ordinal))
                {
                    changes.Add(System.Tuple.Create("GÜNCELLENDİ", ChangedFields(baseline[key], record), record));
                }
            }
        
            if (System.IO.File.Exists(baselinePath))
            {
                string hist = System.IO.Path.Combine(historyDir, "baseline_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".tsv");
                System.IO.File.Copy(baselinePath, hist, true);
            }
        
            string outputPath = "";
            if (changes.Count > 0)
            {
                outputPath = System.IO.Path.Combine(outDir, "Yeni_Guncellenenler_" + System.DateTime.Now.ToString("yyyy-MM-dd_HHmmss") + ".xlsx");
                WriteXlsx(outputPath, changes);
            }
        
            SaveBaseline(baselinePath, records);
            System.IO.File.WriteAllText(statePath, currentMax, new System.Text.UTF8Encoding(false));
        
            if (changes.Count == 0)
            {
                ShowMessage("Tarama tamamlandı.\nToplam kayıt: " + records.Count.ToString("N0") + "\nYeni/Güncellenen: 0\n\nTüm kayıtlar Excel:\n" + allOutputPath, "FDB Takip");
                try
                {
                    var psi = new System.Diagnostics.ProcessStartInfo("explorer.exe", "/select,\"" + allOutputPath + "\"");
                    psi.UseShellExecute = true;
                    System.Diagnostics.Process.Start(psi);
                }
                catch { }
            }
            else
            {
                ShowMessage("Tarama tamamlandı.\nToplam kayıt: " + records.Count.ToString("N0") + "\nYeni/Güncellenen: " + changes.Count.ToString("N0") + "\n\nTüm kayıtlar:\n" + allOutputPath + "\n\nYeni/Güncellenen:\n" + outputPath, "FDB Takip");
                try
                {
                    var psi = new System.Diagnostics.ProcessStartInfo("explorer.exe", "/select,\"" + outputPath + "\"");
                    psi.UseShellExecute = true;
                    System.Diagnostics.Process.Start(psi);
                }
                catch { }
            }
        }
        catch (System.Exception ex)
        {
            ShowMessage("HATA:\n" + ex.Message, "FDB Takip");
            throw;
        }
    }
}
