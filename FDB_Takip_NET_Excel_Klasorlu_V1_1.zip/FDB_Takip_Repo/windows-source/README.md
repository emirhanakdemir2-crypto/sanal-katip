# FDB Takip - Windows (.NET)

Bu sürüm UiPath kullanmadan çalışır.

## Çıktı klasörü

Her taramada otomatik olarak şu klasör kullanılır:

`Belgeler\FDB Takip Ciktilari`

Klasörde:

- `Tum_Kayitlar.xlsx` — seçilen FDB'deki bütün kayıtların en güncel hali. Her taramada yenilenir.
- `Yeni_Guncellenenler_YYYY-MM-DD_HHmmss.xlsx` — yalnız yeni veya değişen kayıt varsa oluşturulur. Eski değişiklik dosyaları silinmez.

İlk taramada da `Tum_Kayitlar.xlsx` oluşturulur.

## Çalıştırma

```powershell
dotnet build
dotnet run
```

Çift tıklanabilir yerel sürüm için:

```powershell
dotnet publish -c Release -r win-x64 --self-contained false
```

Kaynak FDB'ye yazılmaz. Okuma geçici Firebird yedeği/kopyası üzerinden yapılır.
