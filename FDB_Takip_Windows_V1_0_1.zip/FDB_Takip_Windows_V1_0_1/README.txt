﻿FDB TAKİP – WINDOWS V1.0.1
======================

KULLANIM
1. ZIP dosyasını bir klasöre çıkarın.
2. FDB_Takip.bat dosyasına çift tıklayın.
3. Güncel .FDB dosyasını seçin.
4. “TARA VE KARŞILAŞTIR” düğmesine basın.
5. Yeni + güncellenen kayıtlar tek .xlsx dosyasında oluşur.

Başlangıç hafızası hazırdır:
- Gönderdiğiniz DOSYATKP(1).FDB içindeki 13.229 kayıt baz alınmıştır.
- Aynı FDB taranırsa 0 yeni / 0 güncellenen çıkmalıdır.

Takip edilen alanlar:
E.Yılı, E.No, Başkan, Tek Hakim, Dava Tarihi, Hdf (HEDEFSURE), Hedef Tarih,
Dava Türü, UYAP Dava Türü, Dosya Durumu, Ele Alınma Tarihi, Davacı, Davalı,
Duruşma Tarihi, Keşif Tarihi, Keşif Saati, Keşif Yeri, Bilirkişi Ver. Tarihi,
K.Yıl, K.No, Karar Tarihi, Verilen Karar, UYAP Açıklaması, Son İşlem Tarihi.

GÜVENLİK
- Kaynak .FDB'ye SQL UPDATE/INSERT/DELETE yapılmaz.
- Program Firebird gbak ile okuma yedeği alır, bunu geçici klasöre geri yükler ve sorguyu geçici kopyada çalıştırır.
- Eski görünen bir FDB seçilirse hafıza geriye alınmaz.
- Her başarılı taramadan önce önceki hafızanın yedeği saklanır.

FIREBIRD
Program önce bilgisayardaki Firebird isql.exe + gbak.exe araçlarını otomatik arar.
Bulamazsa resmi Firebird 4.0.7 x64 taşınabilir paketini otomatik indirmeyi teklif eder.
İnternet yoksa mevcut Firebird kurulumundaki isql.exe dosyasını bir kez seçebilirsiniz.

ÇIKTI
Belgeler\FDB Takip Ciktilari\Yeni_Guncellenenler_YYYY-AA-GG_SS-DD-SS.xlsx

Not: Bu V1, Windows 10/11 64-bit için hazırlanmıştır.


V1.0.1 DÜZELTMESİ
- PowerShell XML/XLSX oluşturma bölümündeki tırnak kaçış hatası düzeltildi.
- Başlatıcı artık PowerShell execution policy ayarını değiştirmez.
